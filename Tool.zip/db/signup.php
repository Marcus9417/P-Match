<?php

include'connect.php';
include'template/signup.html';