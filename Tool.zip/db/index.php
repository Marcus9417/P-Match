<?php
include('check.php');
//include_once'connect.php';

//var_dump($_SESSION);
include'template/index.html';