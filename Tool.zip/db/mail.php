<?php

include'connect.php';
include'template/mail.html';