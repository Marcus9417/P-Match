﻿# Host: localhost  (Version: 5.5.53)
# Date: 2019-11-19 08:55:39
# Generator: MySQL-Front 5.3  (Build 4.234)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "account"
#

DROP TABLE IF EXISTS `account`;
CREATE TABLE `account` (
  `userid` int(10) NOT NULL AUTO_INCREMENT,
  `user` varchar(100) DEFAULT '',
  `pwd` varchar(100) DEFAULT '',
  `email2` varchar(100) DEFAULT '',
  `lastname` varchar(45) DEFAULT '',
  `Firstname` varchar(45) DEFAULT '',
  `street` varchar(100) DEFAULT '',
  `city` varchar(100) DEFAULT '',
  `state` varchar(100) DEFAULT '',
  `zipcode` varchar(100) DEFAULT '',
  `phone` varchar(100) DEFAULT '',
  `hit` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

#
# Data for table "account"
#

INSERT INTO `account` VALUES (1,'it485','123','doctorgreen2333@gmail.com','umass','it485','954 tremont street       ','boston','Ma','02118','123','123'),(2,'jacob','123','jacob91238@gmail.com','wang','jacob','954 tremont street','boston','Ma','02118','6173332321','123'),(4,'Charlene','//123456','Xiaochun.Kuang001@umb.edu','Kuang','Xiaochun','','','','','','//'),(5,'Xinyuan','gxy13572459653','gxy930227@gmail.com','Guo','Xinyuan','11E Newton ST, Apt 304','BOSTON','MA','02118','8572843032','123'),(6,'Jacob','123','doctorgreen2333@gmail.com','Wang','Jacob','','','','','','123'),(9,'123456','123','123@123.com','wang','jia','425 massave apt4','boston','ma','02118','6176893242','123'),(10,'abc','123','123@123.com','wang','jia','425 massave apt4','boston','ma','02118','6176893242','123'),(12,'nelsonho','123','123@123.com','wang','jia','425 massave apt4','boston','ma','02118','6176893242','123'),(13,'aa','5dcefc19ad9ec','cnice103@126.com','cc','bb','','','','','','aa'),(14,'user1','111','123@123.com','2','1','','','','','','123'),(15,'user2','111','123@123.com','2','1','','','','','','123');

#
# Structure for table "book"
#

DROP TABLE IF EXISTS `book`;
CREATE TABLE `book` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `bookname` varchar(100) DEFAULT '',
  `bookau` varchar(100) DEFAULT '',
  `isbn` varchar(45) DEFAULT '',
  `course` varchar(100) DEFAULT '',
  `conditionss` varchar(100) DEFAULT '',
  `edition` varchar(100) DEFAULT '',
  `email` varchar(100) DEFAULT '',
  `content` varchar(255) DEFAULT '',
  `pic` varchar(45) DEFAULT NULL,
  `userid` varchar(100) DEFAULT '',
  `price` varchar(100) DEFAULT '',
  `sellerusername` varchar(100) DEFAULT NULL,
  `selltime` varchar(100) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

#
# Data for table "book"
#

INSERT INTO `book` VALUES (2,'GENKI I','Eri Banno','9784789014410','Japan101','Like new','2','jacobyf2333@gmail.com','Very useful Japanese Book','','1','20','it485','2019-04-22 14:03:58'),(4,'Starting Out with Python','Tony Gaddis','9780133582734','IT116','Like new','3','jacobyf2333@gmail.com','Want to trade on campus. Please contact my email.','5cbe2d9bacd5e.jpg','1','17','it485','2019-04-22 14:09:47'),(7,'Business Statistics For Contemporary Decision Making','Decision Making Ken Black','9781118494769','IT111','New','8','jacobyf2333@gmail.com','Text Book','5cbe3e1888d80.jpg','2','50','jacob','2019-04-22 15:20:08'),(9,'Guide to Networking Essentials ','Greg Tomsho','978-1305105430','IT 246','Used ','7th Edition','Xiaochun.Kuang001@umb.edu','Used book but in very good condition! Some highlights and notes. Welcome to contact me for more info! Price negotiable :)','','4','35','Charlene','2019-05-01 14:20:45'),(12,'Essentials of Understanding Psychology',' Robert S Feldman','978-0077861889','','Like new','11','gxy930227@gmail.com','','5cca13fd6402c.jpg','5','25','Xinyuan','2019-05-01 14:47:41'),(13,'Getting Real About Race','Stephanie M. McClure, Cherise A. Harris ','978-1506339306','SOCIAL 211G','New','2','gxy930227@gmail.com','You will be asked to read many articles from this book. If you are taking SOCIAL 211G, you definitely need this book.','5cca155b7fec9.jpg','5','30','Xinyuan','2019-05-01 14:53:31'),(14,'Microeconomics','Paul Krugman','978-1464143878','ECON 101','Used','4','gxy930227@gmail.com','Great book if you are interested in the economy.','5cca16486545e.jpg','5','50','Xinyuan','2019-05-01 14:57:28'),(15,'Tableau 9: The Official Guide ','George Peck','978-0-07-184329-4','IT 370','Used ','9','Xiaochun.Kuang001@umb.edu','This book is in excellent used condition. Just like a new one! ','5cca3580b3d71.jpg','4','46','Charlene','2019-05-01 17:10:40'),(19,'Applied calculus','by Deborah Hughes Hallett','9781118494769','MATH135','New','4','jacob91238@gmail.com','MATH 135 textbook','5cd071a5b31d8.jpg','2','50','jacob','2019-05-06 10:40:53'),(23,'Jiaqiang Wang',' Charlie Kaufman • Radia Perlman • Mike','0130460192','IT443','Used','2','jacob91238@gmail.com','IT443 text book','5cd33ed1395e5.jpg','2','30','jacob','2019-05-08 13:40:49'),(27,'Windows server 2012 pocket consultant','William R. Stanek','978-0735666337','IT442','Like new','2','jacob91238@gmail.com','IT442 textbook','5cd344119ba28.jpg','2','30','jacob','2019-05-08 14:03:13'),(28,'Strangers Drowning: Impossible Idealism, Drastic Choices, and the Urge to Help','MacFarquhar, Larissa','978-0143109785','Phil 207','New ','2rd','charlenekuang1255@gmail.com','It is excellent new book! Welcome to buy it! ','5cd5b65be983d.jpg','4','7.99','Charlene','2019-05-10 10:35:23'),(31,'Plato: Five Dialogues: Euthyphro, Apology, Crito, Meno, Phaedo (Hackett Classics)','Plato (Author), John M. Cooper (Editor), G. M. A. Grube (Translator)','978-0872206335','Phil 207','Good used','2rd','Xiaochun.Kuang001@umb.edu','Very good philosophy book in a very good used condition! Welcome to email me for more detail info! Thank you :)','5cd5b86af2131.jpg','4','6','Charlene','2019-05-10 10:44:10'),(32,'Star Schema: The Complete Reference','Christopher Adamson ','978-0071744324','IT471','Used','1','gxy930227@gmail.com','Price can be reduced if trade on campus.','5cd5b89c2d5d2.jpg','5','15','Xinyuan','2019-05-10 10:45:00'),(33,'Managerial Decision Modeling with Spreadsheets (3rd Edition)',' Barry Render, Jr. Ralph M. Stair ','978-0136115830','','Good used','3','Xiaochun.Kuang001@umb.edu','In good used condition. ','5cd5b948cb018.jpg','4','79.99','Charlene','2019-05-10 10:47:52'),(35,'Applied Mathematics for the Managerial, Life, and Social Sciences','Soo T. Tan','978-1305107908','MATH 134','Like new','7','gxy930227@gmail.com','','5cd5b959b15e9.jpg','5','55','Xinyuan','2019-05-10 10:48:09'),(36,'Murach Java Programming','Joel Murach','9781943872077','','Like new','5','jacob91238@gmail.com','','5cd5ba27c5706.jpg','2','25','jacob','2019-05-10 10:51:35'),(37,'Java For Everyone: Late Objects','Horstmann, Cay S','9781118063316','','Like new','3','jacob91238@gmail.com','','5cd5bb7d1480b.jpg','2','10','jacob','2019-05-10 10:57:17'),(38,'HTML, CSS and JavaScript All in One','Pearson Education','9780672337147','','Like new','3','jacob91238@gmail.com','','5cd5bbf0f0853.jpg','2','7','jacob','2019-05-10 10:59:12');

#
# Structure for table "car"
#

DROP TABLE IF EXISTS `car`;
CREATE TABLE `car` (
  `id` int(11) NOT NULL,
  `Part Name` varchar(45) DEFAULT NULL,
  `Name` varchar(45) DEFAULT NULL,
  `Year` varchar(45) DEFAULT NULL,
  `Make` varchar(45) DEFAULT NULL,
  `Model` varchar(45) DEFAULT NULL,
  `Pic` varchar(45) DEFAULT NULL,
  `Price` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "car"
#

INSERT INTO `car` VALUES (1,'Oil filter','STP Extended Life Oil Filter S10075XL ','2013','BMW','328i','1571704307(1).png','$13.99'),(2,'Oil filter','Mobil1 Oil Filter M1C-155A','2013','BMW','328i','1571704410(1).png','$19.99'),(3,'Oil filter','STP Oil Filter S10075','2013','BMW','328i','1571704465(1).png','$9.99'),(4,'Spark Plug','NGK Laser Iridium Spark Plug 97506','2013','BMW','328i','1571705048(1).png','$21.99'),(5,'Spark Plug','Bosch Double Platinum Spark Plug 8165','2013','BMW','328i','1571705058(1).png','$15.99'),(6,'Brake Pads','Duralast Semi-Metallic Brake Pads MKD1561','2013','BMW','328i','1571706486(1).png','$31.49'),(7,'Brake Pads','Duralast Gold Semi-Metallic Brake Pads DG1561','2013','BMW','328i','1571706497(1).png','$42.99'),(8,'Brake Pads','Brembo Brake Pads - Rear','2013','BMW','328i','1571706506(1).png','$85.49'),(9,'Brake Pads','Duralast Max Ceramic Brake Pads DGC1613','2013','BMW','328i','1571706517(1).png','$69.99'),(10,'Brake Pads','Duralast Gold Ceramic Brake Pads DG1613','2013','BMW','328i','1571706524(1).png','$59.99'),(11,'Wiper Blade (Windshield)','Bosch Envision 24in Wiper Blade','2013','BMW','328i','1572028608(1).png','$29.99'),(12,'Wiper Blade (Windshield)','Rain X AdvantEdge 19in Wiper Blade','2013','BMW','328i','1572028675(1).png','$31.99'),(13,'Wiper Blade (Windshield)','Duralast Flex 24in Wiper Blade','2013','BMW','328i','1572028741(1).png','$18.99'),(14,'Air Filter','STP Air Filter SA11305','2013','BMW','328i','1572028873(1).png','$19.99'),(15,'Air Filter','K&N High Performance Air Filter 33-2990','2013','BMW','328i','1572028926(1).png','$54.99'),(16,'Air Filter ','Fram Air Filter CA11305','2013','BMW','328i','1572028980(1).png','$25.99'),(17,'Oil filter','STP Extended Life Oil Filter S10515XL','2015','Hyundai ','Genesis Coupe 3.8 ','1572029367(1).png','$8.99'),(18,'Oil filter','STP Oil Filter S10515','2015','Hyundai ','Genesis Coupe 3.8 ','1572029525(1).png','$4.99'),(19,'Oil filter','K & N Pro-Series Oil Filter PS-7022','2015','Hyundai ','Genesis Coupe 3.8 ','1572029594(1).png','$8.99'),(20,'Spark Plug','Autolite XP Iridium Spark Plug XP5702','2015','Hyundai ','Genesis Coupe 3.8 ','1572033340(1).png','$7.99'),(21,'Spark Plug','NGK Laser Iridium Spark Plug 9723','2015','Hyundai ','Genesis Coupe 3.8 ','1572033411(1).png','$15.99'),(22,'Brake Pads','Duralast Gold Ceramic Brake Pads DG1413','2015','Hyundai ','Genesis Coupe 3.8 ','1572033572(1).png','$48.99'),(23,'Brake Pads','Brembo Brake Pads - Front','2015','Hyundai ','Genesis Coupe 3.8 ','1572033636(1).png','$76.99'),(24,'Brake Pads','Duralast Max Ceramic Brake Pads DGC1284','2015','Hyundai ','Genesis Coupe 3.8 ','1572033716(1).png','$59.99'),(25,'Wiper Blade (Windshield)','Rain X AdvantEdge 16in Wiper Blade','2015','Hyundai ','Genesis Coupe 3.8 ','1572033867(1).png','$31.99'),(26,'Wiper Blade (Windshield)','Bosch Envision 24in Wiper Blade','2015','Hyundai ','Genesis Coupe 3.8 ','1572033844(1).png','$29.99'),(27,'Wiper Blade (Windshield)','Duralast Flex 20in Wiper Blade','2015','Hyundai ','Genesis Coupe 3.8 ','1572033923(1).png','$18.99'),(28,'Air Filter','STP Air Filter SA11298','2015','Hyundai ','Genesis Coupe 3.8 ','1572033977(1).png','$19.99'),(29,'Air Filter','Fram Air Filter CA11298','2015','Hyundai ','Genesis Coupe 3.8 ','1572034006(1).png','$24.99'),(30,'Oil filter','STP Extended Life Oil Filter S2XL','2013','Ford','E-350 Super Duty','1572029762(1).png','$8.99'),(31,'Oil filter','STP Oil Filter S2','2013','Ford','E-350 Super Duty','1572029825(1).png','$4.99'),(32,'Oil filter','Mobil1 Oil Filter M1-210','2013','Ford','E-350 Super Duty','1572029893(1).png','$14.99'),(33,'Spark Plug','ACDelco Double Platinum Spark Plug 41-810','2013','Ford','E-350 Super Duty','1572030185(1).png','$7.49'),(34,'Spark Plug','Denso Double Platinum Spark Plug 5070','2013','Ford','E-350 Super Duty','1572030260(1).png','$8.79'),(35,'Spark Plug','NGK Laser Double Platinum Spark Plug 7740','2013','Ford','E-350 Super Duty','1572030335(1).png','$10.19'),(36,'Brake Pads','Duralast Gold Ceramic Brake Pads DG1328','2013','Ford','E-350 Super Duty','1572034096(1).png','$67.99'),(37,'Brake Pads','Max Semi-Metallic Brake Pads DGC1328M','2013','Ford','E-350 Super Duty','1572034067(1).png','$77.99'),(38,'Wiper Blade (Windshield)','Duralast Aero 20in Wiper Blade Hybrid Design','2013','Ford','E-350 Super Duty','1572034142(1).png','$19.99'),(39,'Wiper Blade (Windshield)','Bosch SnowDriver 20in Wiper Blade','2013','Ford','E-350 Super Duty','1572034160(1).png','$16.99'),(40,'Wiper Blade (Windshield)','Winter 20in Wiper Blade Conventional Design','2013','Ford','E-350 Super Duty','1572034191(1).png','$13.99'),(41,'Air Filter','Spectre Performance Air Filter HPR8039','2013','Ford','E-350 Super Duty','1572034218(1).png','$34.99'),(42,'Air Filter','STP Premium Air Filter PSA8039','2013','Ford','E-350 Super Duty','1572034238(1).png','$24.99'),(43,'Air Filter','K&N High Performance Air Filter E-0945','2013','Ford','E-350 Super Duty','1572034264(1).png','$62.99');

#
# Structure for table "cart"
#

DROP TABLE IF EXISTS `cart`;
CREATE TABLE `cart` (
  `orderid` int(11) NOT NULL AUTO_INCREMENT,
  `id` varchar(45) DEFAULT '',
  `bookname` varchar(100) DEFAULT '',
  `bookau` varchar(100) DEFAULT '',
  `isbn` varchar(45) DEFAULT '',
  `course` varchar(45) DEFAULT '',
  `conditionss` varchar(45) DEFAULT '',
  `edition` varchar(45) DEFAULT '',
  `email` varchar(45) DEFAULT '',
  `content` varchar(100) DEFAULT '',
  `pic` varchar(45) DEFAULT '',
  `userid` varchar(45) DEFAULT '',
  `buyerid` varchar(45) DEFAULT '',
  `price` varchar(100) DEFAULT '',
  `sellerusername` varchar(100) DEFAULT '',
  `buyerusername` varchar(100) DEFAULT '',
  PRIMARY KEY (`orderid`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

#
# Data for table "cart"
#

INSERT INTO `cart` VALUES (8,'14','Microeconomics','Paul Krugman','978-1464143878','ECON 101','Used','4','gxy930227@gmail.com','Great book if you are interested in the economy.','5cca16486545e.jpg','5','4','50','Xinyuan','Charlene'),(15,'35','Applied Mathematics for the Managerial, Life, and Social Sciences','Soo T. Tan','978-1305107908','MATH 134','Like new','7','gxy930227@gmail.com','','5cd5b959b15e9.jpg','5','1','55','Xinyuan','it485'),(16,'28','Strangers Drowning: Impossible Idealism, Drastic Choices, and the Urge to Help','MacFarquhar, Larissa','978-0143109785','Phil 207','New ','2rd','charlenekuang1255@gmail.com','It is excellent new book! Welcome to buy it! ','5cd5b65be983d.jpg','4','1','7.99','Charlene','it485');

#
# Structure for table "cpu"
#

DROP TABLE IF EXISTS `cpu`;
CREATE TABLE `cpu` (
  `id` int(11) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Core Count` varchar(100) DEFAULT NULL,
  `Core Clock` varchar(100) DEFAULT NULL,
  `Boost Clock` varchar(100) DEFAULT NULL,
  `TDP` varchar(100) DEFAULT NULL,
  `Integrated Graphics` varchar(100) DEFAULT NULL,
  `SMT` varchar(100) DEFAULT NULL,
  `Pic` varchar(100) DEFAULT NULL,
  `Price` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "cpu"
#

INSERT INTO `cpu` VALUES (1,'AMD Ryzen 5 3600','6','3.6GHz','4.2GHz','65 W','None','Yes','c7baf2c9c9cc15ae23adb24c2f4316fc.1600.jpg','$194.79'),(2,'Intel Core i9-9900K','8','3.6GHz','5.0GHz','95 W','Intel UHD Graphics 630','Yes','41EDFtP5hpL.jpg','$484.99'),(3,'Intel Core i7-9700K','8','3.6GHz','4.9GHz','95 W','Intel UHD Graphics 630','Yes','3760e89d1820da393f084e2c18a62e3b.1600.jpg','$359.00'),(4,'Intel Core i5-9600K ','6','3.7GHz','4.6GHz','95 W','Intel UHD Graphics 630','No','33f96aec821c5c10f4b1fd636a7d1881.1600.jpg','$233.99'),(5,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

#
# Structure for table "cpu cooler"
#

DROP TABLE IF EXISTS `cpu cooler`;
CREATE TABLE `cpu cooler` (
  `id` int(11) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Fan RPM` varchar(100) DEFAULT NULL,
  `Noise Level` varchar(100) DEFAULT NULL,
  `Color` varchar(100) DEFAULT NULL,
  `Radiator Size` varchar(100) DEFAULT NULL,
  `Pic` varchar(100) DEFAULT NULL,
  `Price` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "cpu cooler"
#

INSERT INTO `cpu cooler` VALUES (1,'Cooler Master Hyper 212 EVO','600 - 2000 RPM','9 - 36 db','',NULL,'ddea57de9797549e80d05fb3acb2e83d.med.1600.jpg','$29.89'),(2,'Corsair H100i RGB PLATINUM','2400 RPM','37 dB','Black / Silver','240 mm','623066a73a9f4feafdea3ae659f80705.1600.jpg','$134.99'),(3,'Cooler Master MasterLiquid ML240L RGB','650 - 2000 RPM','6 - 30 dB',NULL,'240 mm','a34cda2e4fd2837ff90811e8395be84b.1600.jpg','$61.88'),(4,'Corsair H100i PRO','2400 RPM','37 dB','Black','40 mm','727b2d396d060c5982ad3fa62e0fdd42.1600.jpg','$131.89'),(5,'Cooler Master Hyper 212 RGB Black Edition','650 - 2000 RPM','8 - 30 dB','Black',NULL,'51XdFIoS4DL.jpg','$38.99');

#
# Structure for table "motherboard"
#

DROP TABLE IF EXISTS `motherboard`;
CREATE TABLE `motherboard` (
  `id` int(11) NOT NULL,
  `Name` varchar(45) DEFAULT NULL,
  `Socket / CPU` varchar(45) DEFAULT NULL,
  `Form Factor` varchar(45) DEFAULT NULL,
  `RAM Slots` varchar(45) DEFAULT NULL,
  `Max RAM` varchar(45) DEFAULT NULL,
  `Color` varchar(45) DEFAULT NULL,
  `Pic` varchar(45) DEFAULT NULL,
  `Price` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "motherboard"
#

INSERT INTO `motherboard` VALUES (1,'MSI B450 TOMAHAWK','AM4','ATX','4','64 GB','Black / Silver','8ba566ff15c0bdf7435a68cc0e5152fa.1600.jpg','$111.89'),(2,'Asus ROG STRIX B450-F GAMING','AM4','ATX','4','64 GB','Black','66e5b5e4d0a52b6a2f99bb53bf52eee7.1600.jpg','$119.89'),(3,'Asus ROG STRIX Z390-E GAMING','LGA1151','ATX','4','128 GB','Black','7fe5cb1d35e7385f6cd195e787ab9274.1600.jpg','$232.99'),(4,'Asus ROG RAMPAGE VI EXTREME OMEGA','LGA2066','EATX','8','128 GB','Black','518PBluw90L.jpg','$745.67'),(5,'Gigabyte Z390 AORUS MASTER','LGA1151','ATX','4','128 GB','Black / Silver','b44c9eb2fa9abaf62e3e7ce90ec7da3e.1600.jpg','$289.99');

#
# Structure for table "orders"
#

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `ordernumber` int(11) NOT NULL AUTO_INCREMENT,
  `sellerid` varchar(45) DEFAULT '',
  `selleremail` varchar(45) DEFAULT '',
  `sellerphone` varchar(45) DEFAULT '',
  `buyerid` varchar(45) DEFAULT '',
  `buyeremail` varchar(45) DEFAULT '',
  `buyerphone` varchar(45) DEFAULT '',
  `shipaddress` varchar(100) DEFAULT '',
  `status` varchar(45) DEFAULT '',
  `confirm` varchar(45) DEFAULT '',
  `bookid` varchar(45) DEFAULT '',
  `bookname` varchar(100) DEFAULT '',
  `pic` varchar(45) DEFAULT NULL,
  `price` varchar(45) DEFAULT '',
  `ordertime` varchar(100) DEFAULT '',
  `sellerusername` varchar(100) DEFAULT '',
  PRIMARY KEY (`ordernumber`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

#
# Data for table "orders"
#

INSERT INTO `orders` VALUES (3,'1','doctorgreen2333@gmail.com','','2','jacobyf2333@gmail.com','6173332321','944 tremont street boston Ma,02116','4','1','3','SQL in 10 Minutes','5cbe2cda7c3f7.jpg','15','2019-04-22','it485'),(4,'1','jacobyf2333@gmail.com','','1','doctorgreen2333@gmail.com','123','954 tremont street    boston Ma,02118','4','1','5','Ethical hacking and countermeas','5cbe318dab9c4.jpg','20','2019-04-25','it485'),(5,'2','jacobyf2333@gmail.com','','1','doctorgreen2333@gmail.com','123','954 tremont street    boston Ma,02118','4','1','6','Applied calculus','5cbe3b13285b4.jpg','30','2019-04-29','jacob'),(6,'2','jacob91238@gmail.com','','1','doctorgreen2333@gmail.com','123','954 tremont street      boston Ma,02118','4','1','18','Applied calculus','5cd06824dfb0e.jpg','45','2019-05-06','jacob'),(7,'2','jacob91238@gmail.com','','1','doctorgreen2333@gmail.com','123','954 tremont street      boston Ma,02118','4','1','17','Ethical hacking and countermeas','5cd06791423ce.jpg','27','2019-05-06','jacob'),(8,'2','jacob91238@gmail.com','','1','doctorgreen2333@gmail.com','123','954 tremont street      boston Ma,02118','4','1','16','Information Technology Project Management','5cd0666d9a4b2.jpg','28','2019-05-06','jacob'),(9,'1','gxy930227@gmail.com','','2','jacob91238@gmail.com','6173332321','954 tremont street boston Ma,02118','4','1','39','CSS The Missing Manual','5cd9aff9330b6.jpg','22','2019-05-13','it485'),(10,'2','jacob91238@gmail.com','','11','123@123.com','6176893242','425 massave apt4 boston ma,02118','4','1','29','Learn Windows PowerShell in a Month of Lunches ','5cd5b72f7f0b8.jpg','20','2019-05-13','jacob'),(11,'2','jacob91238@gmail.com','','12','123@123.com','6176893242','425 massave apt4 boston ma,02118','4','1','26','The Practice of System and Network Administration','5cd3420ed0b7e.jpg','25','2019-05-13','jacob');

#
# Structure for table "product"
#

DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `make` varchar(45) DEFAULT NULL,
  `model` varchar(45) DEFAULT NULL,
  `year` varchar(45) DEFAULT NULL,
  `pic` varchar(45) DEFAULT NULL,
  `price` varchar(45) DEFAULT NULL,
  `part_name` varchar(45) DEFAULT NULL,
  `core_count` varchar(45) DEFAULT NULL,
  `core_clock` varchar(45) DEFAULT NULL,
  `boost_clock` varchar(45) DEFAULT NULL,
  `tdp` varchar(45) DEFAULT NULL,
  `integrated_graphics` varchar(45) DEFAULT NULL,
  `smt` varchar(45) DEFAULT NULL,
  `userid` varchar(45) DEFAULT NULL,
  `sellerusername` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `selltime` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

#
# Data for table "product"
#

INSERT INTO `product` VALUES (4,'car','STP Extended Life Oil Filter S10075XL ','BMW','328i','2013','1571704307(1).png','13.99','Oil filter',NULL,NULL,NULL,NULL,NULL,NULL,'1','it485','123@123.com',NULL),(5,'car','NGK Laser Iridium Spark Plug 97506','BMW','328i','2013','1571705048(1).png','21.99 ','Spark Plug',NULL,NULL,NULL,NULL,NULL,NULL,'1','it485','123@123.com',NULL),(6,'car','Bosch Envision 24in Wiper Blade','BMW','328i','2013','1572028608(1).png','29.99 ','Wiper Blade (Windshield)',NULL,NULL,NULL,NULL,NULL,NULL,'1','it485','123@123.com',NULL),(7,'car','STP Extended Life Oil Filter S10515XL','Hyundai ','Genesis Coupe 3.8 ','2015','1572029367(1).png','8.99 ','Oil filter',NULL,NULL,NULL,NULL,NULL,NULL,'1','it485','123@123.com',NULL),(8,'car','STP Extended Life Oil Filter S2XL','Ford','E-350 Super Duty','2013','1572029762(1).png','8.99 ','Oil filter',NULL,NULL,NULL,NULL,NULL,NULL,'1','it485','123@123.com',NULL),(9,'cpu','AMD Ryzen 5 3600',NULL,NULL,NULL,'c7baf2c9c9cc15ae23adb24c2f4316fc.1600.jpg','194.79 ',NULL,'6','3.6GHz','4.2GHz','65 W','None','Yes','1','it485','123@123.com',NULL),(10,'cpu','Intel Core i9-9900K',NULL,NULL,NULL,'41EDFtP5hpL.jpg','484.99 ',NULL,'8','3.6GHz','5.0GHz','95 W','Intel UHD Graphics 630','Yes','1','it485','123@123.com',NULL),(11,'cpu',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(12,'cpu','Intel Core i7-9700K',NULL,NULL,NULL,'5dd2ba4858aad.jpg','$359.00 ',NULL,'8','3.6GHz','4.9GHz','95 W','Intel UHD Graphics 630','Yes','1','it485','123@123.COM','2019-11-18 15:35:34');
