<?php
 include('check.php');

 if( isset($_SESSION['login']) === false) 
 { 
    header("location: trans_require_login.php");

    die;
 }
 include('connect.php');
 $id= $_GET['id'];
 $db->query("SET NAMES UTF8");
 $sql = "delete from product where id = '$id'";
 $is = $db->query($sql); 
 echo "<script>alert('Delete successful'); history.go(-1);</script>";