<?php
include('check.php');

?>


<!DOCTYPE html>
<html>
<!-- custom-theme -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //custom-theme -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="css/lightbox.css">
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<!-- font-awesome-icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome-icons -->
<link href="http://fonts.googleapis.com/css?family=Oswald:300,400,700&amp;subset=latin-ext" rel="stylesheet">
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- header -->
<div class="header_address_mail">
		<div class="container">
			<div class="agileits_w3layouts_header_address_grid">
			<?php
                    if( isset($_SESSION['user']) === false) 
                     {
                    ?>   
				<ul>	
					<li style=""><a style="" href="login.php">Log In</a></li>
					
					<li><a href="signup.php">Sign up</a></li>
					
				</ul>
				<?php
				}else{
                    $username = $_SESSION['user'];
					
                    ?>
					<ul>
					<li><a href="profile.php"><?php echo $username?></a></li>
					
					<li><a href="selling.php" style="color:#fff;">Upload</a></li>
					
					<li><a href="logout.php">Logout</a></li>
					</ul>
				<?php
				}
				?>
			</div>
		</div>
	</div>
	<div class="header">
		<div class="container">
			<div class="w3_agile_logo">
				<h1><a>
				<img src="images/logo.png" alt="Logo" height="51" width="165"></a></h1>
			</div>
			<div class="header-nav">
				<nav class="navbar navbar-default">
					<div class="navbar-header navbar-left">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
					</div>
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
						<nav class="link-effect-12">
							<ul class="nav navbar-nav w3_agile_nav">
								<li class="active"><a href="index.php"><span>Home</span></a></li>
								<li><a href="resultblank.php"><span>Detail Search</span></a></li>
								<li><a href="about.php"><span>About Us</span></a></li>
								<li><a href="mail.php"><span>Mail Us</span></a></li>
							</ul>
						</nav>
					</div>
				</nav>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
    </div>

<body>
    <div style = "height:200px"></div>
    <h2 class="trans-h" style = "text-align:center">Profile has been updated</h2>
    <h3 class="trans-l" style = "text-align:center"><a href="index.php" class="trans-l">Back to Home page</a></p>
    
 
</body>
</html>