<?php
include('connect.php');
require_once('vendor/autoload.php');






//$newpassword = md5(uniqid());
$newpassword = uniqid();
$user = isset($_POST['user'])? $_POST['user'] : ''; 
$email2 = isset($_POST['email2'])? $_POST['email2'] : ''; 

$hit = isset($_POST['hit'])? $_POST['hit'] : '';

if( !empty($user) && !empty($email2) && !empty($hit)){

    $sql = "select * from account where user='{$user}' and email2='{$email2}' and hit='{$hit}'";
    $mysqli_result = $db-> query($sql);
    $row = $mysqli_result->fetch_array(MYSQLI_ASSOC);
    
    
    
   
    if ( is_array($row)) {   
        $sql = "update account set pwd = '{$newpassword}' where user = '{$user}' ";
        $is = $db->query($sql);

       
    }else{
        
        header('location: trans_reset_fail.php');
        die('Username or Email is not correct!');
    }
        ////////////////// email part
require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';
require 'PHPMailer-master/src/Exception.php';
require 'vendor/autoload.php';



$mail = new PHPMailer\PHPMailer\PHPMailer();

try {
    //Server settings
    /*
    $mail->SMTPDebug = 2;                                       // Enable verbose debug output
    $mail->isSMTP();                                            // Set mailer to use SMTP
    $mail->Host       = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = "baibook.umass@gmail.com";                     // SMTP username
    $mail->Password   = "it48512345";                               // SMTP password
    $mail->SMTPSecure = 'tls';                                  // Enable TLS encryption, `ssl` also accepted
    $mail->Port       = 587;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom("baibook.umass@gmail.com", "User: $user");
    $mail->addAddress("$email2", '$user');     // Add a recipient
    // $mail->addAddress('ellen@example.com');               // Name is optional
    // $mail->addReplyTo('info@example.com', 'Information');
    // $mail->addCC('cc@example.com');
    // $mail->addBCC('bcc@example.com');

    // Attachments
    // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
    // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
    */
    //
    //
    $mail->CharSet ="UTF-8";                     //设定邮件编码 
    $mail->SMTPDebug = 0;                        // 调试模式输出 
    $mail->isSMTP();                             // 使用SMTP 
    $mail->Host = 'smtp.qq.com';                // SMTP服务器 
    $mail->SMTPAuth = true;                      // 允许 SMTP 认证 
    $mail->Username = '251744894@qq.com';                // SMTP 用户名  即邮箱的用户名 
    $mail->Password = 'mjdqgfexyoktbjbj';             // SMTP 密码  部分邮箱是授权码(例如163邮箱) 
    $mail->SMTPSecure = 'ssl';                    // 允许 TLS 或者ssl协议 
    $mail->Port = 465;                            // 服务器端口 25 或者465 具体要看邮箱服务器支持 

    $mail->setFrom('251744894@qq.com', 'Mailer');  //发件人 
    $mail->addAddress("$email2", '$user');     // Add a recipient
    //$mail->addAddress('ellen@example.com');  // 可添加多个收件人 
    $mail->addReplyTo('251744894@qq.com', 'info'); //回复的时候回复给哪个邮箱 建议和发件人一致 
    //
    //
    // Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = "Baibook password reset";
    $mail->Body    = "Hello $user! <br> Here is your new passwords $newpassword";
    

    $mail->send();

    if ($mail->ErrorInfo <> ''){
        echo "<script>alert('User name already exists'); history.go(-1);</script>";  
    }else{
        echo "<script>alert('Success！'); window.location.href='index.php'</script>";
        // echo "New password has sent to your email $email2";
    }
    
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

    exit();
}
       






      



?>