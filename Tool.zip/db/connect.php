<?php
$host = 'localhost';
$dbuser = 'root';
$pws = 'root';
$dbname = '20191109_wan_feng';

$db = new mysqli( $host, $dbuser, $pws, $dbname);
if( $db->connect_errno <> 0){
    die('cnnect to databse fail');
}

$db->query("SET NAMES UTF8");


?>