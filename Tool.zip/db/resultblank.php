<?php
 error_reporting(0);

include('page.php');
include('check.php');
include('connect.php');
if (isset($_POST['submit']) == false){
	$title1=' ';
    include'template/resultblank.html';
	die;
}
//$post_arr = array_map('strtolower', $_POST);
//var_dump($post_arr);
//die;

$keyword = $_POST['keyword'];
$keyword=str_replace(" "," ",$keyword); 
$keyword=str_replace(" ",",",$keyword); 
$keyarr=explode(',',$keyword); 
$keyarr = array_map('strtolower',$keyarr);//lower
array_unshift($keyarr, 'x'); //
//var_dump($keyarr);
//exit;
//echo array_search("cpu",$keyarr);
if(array_search("car",$keyarr) != 0)//cpu
{
	
	$keyarr = array_diff($keyarr, ["car"]);
	//var_dump($keyarr);
	array_splice($keyarr,0,1);
	//var_dump($keyarr);
	
	
	for($index=0;$index<count($keyarr);$index++) 
    { 

        $whereSql .= "And (make like '%$keyarr[$index]%' Or model like '%$keyarr[$index]%' Or name like '%$keyarr[$index]%') ";
    } 
    //$whereSql = substr($whereSql,4);
	$sql = "select * from product where category ='car' $whereSql";
	
}
else//else car
{
	array_splice($keyarr,0,1);
	for($index=0;$index<count($keyarr);$index++) 
    { 

    $whereSql .= "And (make like '%$keyarr[$index]%' Or model like '%$keyarr[$index]%' Or year like '%$keyarr[$index]%') ";
    } 

    //$whereSql = substr($whereSql,4);//substr 4
	$sql = "select * from product where category ='pc' $whereSql";

}

$db->query("SET NAMES UTF8");


$mysqli_result= $db->query($sql);
  
//print_r($mysqli_result);
//die;    
    

$rows =[];
while ($row = $mysqli_result ->fetch_array( MYSQLI_ASSOC)){
 
    $rows[$row['id']]= $row; 
	//var_dump($rows);
}
if(is_array($rows) === false){
	$title1 = 'Sorry, We need more information to find a match.';
}
else{
	$title1=' ';
}


include'template/resultblank.html';
die;
if(count($post_arr) ==2)
{


    $keyword = $_POST['keyword'];
    $keyword=str_replace(" "," ",$keyword); 
    $keyword=str_replace(" ",",",$keyword); 
    $keyarr=explode(',',$keyword); 


    $whereSql='';
    for($index=0;$index<count($keyarr);$index++) 
    { 

    $whereSql .= "And (make like '%$keyarr[$index]%' Or model like '%$keyarr[$index]%' Or year like '%$keyarr[$index]%') ";
    } 

    $whereSql = substr($whereSql,4);//substr 4
}
else
{
    $whereSql = "name like '%$_POST[name]%' Or model like '%$_POST[model]%' Or year like '%$_POST[year]%'";
}
//echo $whereSql;
//die;
$db->query("SET NAMES UTF8");
$sql="SELECT * FROM product WHERE $whereSql";

$mysqli_result= $db->query($sql);
  
//print_r($mysqli_result);
//die;    
    

$rows =[];
while ($row = $mysqli_result ->fetch_array( MYSQLI_ASSOC)){
 
    $rows[$row['id']]= $row; 
}
if(is_array($rows) === false){
	$title1 = 'Sorry, We need more information to find a match.';
}
else{
	$title1=' ';
}


include'template/resultblank.html';