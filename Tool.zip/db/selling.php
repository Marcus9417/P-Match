<?php
 include('check.php');
//var_dump($_SESSION);
 if( isset($_SESSION['login']) === false) 
 { 
    

    die;
 }
include'connect.php';
include('page.php');



 $sql = "select count(*) as t from product";
 $mysqli_result= $db->query($sql);
 $row = $mysqli_result->fetch_array( MYSQLI_ASSOC);

 $dataTotal = $row['t'];
 $pageNum = 9;
 $p = new Page($dataTotal, $pageNum );

 $userid= $_SESSION['login'];
 $sql = "select * from product where userid ='$userid'  order by id DESC LIMIT {$p->offset}, {$pageNum};" ; 
 $rows = [];
$mysqli_result =$db->query($sql);
if($mysqli_result == false){
    echo "SQL fail";
    exit;
}





while ($row = $mysqli_result ->fetch_array( MYSQLI_ASSOC)){
     
     $rows[$row['id']]= $row;}
//var_dump($rows);
//die;

include'template/selling.html';
 ?>