<?php

include'connect.php';
include'template/password.html';