<?php

include'connect.php';
include'template/about.html';