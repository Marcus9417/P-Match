<?php
include('connect.php');
include('check.php');

if( isset($_SESSION['login']) === false) 
{ 
    ?>
    <a href="login.php">go to login page</a>
    <?php    
    die('need to login');
}

$userid= $_SESSION['login'];
$sql = "select * from account where userid = {$userid};" ; 
 $rows = [];
$mysqli_result =$db->query($sql);
if($mysqli_result == false){
    echo "SQL fail";
    exit;
}
while ($row = $mysqli_result ->fetch_array( MYSQLI_ASSOC)){
     
     $rows[$row['userid']]= $row; 
}



?>



<!DOCTYPE html>
<html>
<title>Profile</title>
<!-- custom-theme -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //custom-theme -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="css/lightbox.css">
<!-- js -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<!-- font-awesome-icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome-icons -->
<link href="http://fonts.googleapis.com/css?family=Oswald:300,400,700&amp;subset=latin-ext" rel="stylesheet">
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- header -->
<div class="header_address_mail">
		<div class="container">
			<div class="agileits_w3layouts_header_address_grid">
			<?php
                    if( isset($_SESSION['user']) === false) 
                     {
                    ?>   
				<ul>	
					<li style=""><a style="" href="login.php">Log In</a></li>
					
					<li><a href="signup.php">Sign up</a></li>
					
				</ul>
				<?php
				}else{
                    $username = $_SESSION['user'];
					
                    ?>
					<ul>
					<li><a href="profile.php"><?php echo $username?></a></li>
					
					<li><a href="selling.php" style="color:#fff;">Upload</a></li>
					
					<li><a href="logout.php">Logout</a></li>
					</ul>
				<?php
				}
				?>
			</div>
		</div>
	</div>
	<div class="header">
		<div class="container">
			<div class="w3_agile_logo">
				<h1><a>
				<img src="images/logo.png" alt="Logo" height="51" width="165"></a></h1>
			</div>
			<div class="header-nav">
				<nav class="navbar navbar-default">
					<div class="navbar-header navbar-left">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
					</div>
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
						<nav class="link-effect-12">
							<ul class="nav navbar-nav w3_agile_nav">
								<li class="active"><a href="index.php"><span>Home</span></a></li>
								<li><a href="resultblank.php"><span>Detail Search</span></a></li>
								<li><a href="about.php"><span>About Us</span></a></li>
								<li><a href="mail.php"><span>Mail Us</span></a></li>
							</ul>
						</nav>
					</div>
				</nav>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
<!-- header -->
   

<body class="marble-bg">

    <div class="mx-auto contact-form">
        <h3>Contact Information</h3>
        <form action="profilesave.php" method="POST" enctype="multipart/form-data">
        <?php

foreach( $rows as $row){

?>   
            <div class="form-row contact-row">
                <div class="col-sm-12 col-md-6">
                    <div class="form-group"><label>First Name</label><input class="form-control" type="text" name="firstname" value="<?php echo $row['Firstname'];?>"></div>
                    <div class="form-group"><label>Last Name</label><input class="form-control" type="text" name="lastname" value="<?php echo $row['lastname'];?>"></div>
                </div>
                <div class="col-sm-12 col-md-6">
                    <div class="form-group"><label>Phone Number</label><input class="form-control" type="tel" name="phone" value="<?php echo $row['phone'];?>"></div>
                    <div class="form-group"><label>Email</label><input class="form-control" type="email" name="email" value="<?php echo $row['email2'];?>"></div>
                </div>
            </div>
        
        <hr class="profile-line">
    </div>
    <div class="mx-auto pass-form">
        <h3>Password Update</h3>
        
            <div class="form-row contact-row">
                <div class="col-sm-12 col-md-6">
                    <div class="form-group"><label>New Password</label><input class="form-control" type="password" name="pwd" value="<?php echo $row['pwd'];?>"></div>
                    <div class="form-group"><label>Confirmed Password</label><input class="form-control" type="password" name="pwd2" value="<?php echo $row['pwd'];?>"></div>
                </div>
            </div>
            <?php
}
?>
            <hr class="profile-line"><button type="submit" name="btn" class="btn btn-warning float-right save-bt" >SAVE</button></form>


            
    </div>
    <div style="height:150px"></div>
    
   <!-- subscribe -->
	<div class="footer-top">
		<div class="container">
			<div class="col-md-4 welcome">
				<h3>P-Match</h3>
				<p>P-Match is stand for Parts Matching platform.It will able to help people to find components that will match to the specific item. This platform will based on a database that we created.</p>
				
			</div>
			<div class="col-md-3 address">
				<h3>Address</h3>
					<p>University of Massachusetts Boston 
						<span>100 William T, Morrissey Blvd, Boston, MA 02125</span>
					</p>
					<p class="phone">Phone : +1 857-999-5533
						<span>Email : <a href="mailto:IT485@umb.edu">IT485@umb.edu</a></span>
					</p>
			</div>
			<div class="col-md-5 wthree-subscribe">
				<h3>Intermedia</h3>
				<p>Check our update and getting best price!</p>
				<div class="agile_header_social">
					<ul class="agileits_social_list">
						<li><a href="#" class="w3_agile_facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li><a href="#" class="agile_twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						<li><a href="#" class="w3_agile_dribble"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
						<li><a href="#" class="w3_agile_vimeo"><i class="fa fa-vimeo" aria-hidden="true"></i></a></li>
					</ul>
				</div>
			</div>
				<div class="clearfix"></div>
		</div>
    </div>
    
<!-- //subscribe -->
<!-- copy-right -->
	<div class="copy-right-grids">
		<div class="container">
			<div class="copy-left">
				<p class="footer-gd">Copyright &copy; 2017.Company name All rights reserved.</p>
			</div>
				<div class="clearfix"></div>
		</div>
	</div>
<!-- //copy-right -->
<!-- start-smooth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
<!-- start-smooth-scrolling -->
<!-- for bootstrap working -->
	<script src="js/bootstrap.js"></script>
<!-- //for bootstrap working -->
<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear' 
				};
			*/
								
			$().UItoTop({ easingType: 'easeOutQuart' });
								
			});
	</script>
<!-- //here ends scrolling icon -->
</body>

</html>