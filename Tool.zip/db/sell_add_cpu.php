<?php
 include('check.php');
//var_dump($_SESSION);
 if( isset($_SESSION['login']) === false) 
 { 
    

    die;
 }
include'connect.php';
include'template/sell_add_cpu.html';
