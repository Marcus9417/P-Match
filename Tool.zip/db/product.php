<?php


include('connect.php');
include('check.php');

if( isset($_SESSION['login']) === false) 
{ 
   //header("location: trans_require_login.php");
	echo "<script>alert('Please log in first.'); window.location.href='login.php'</script>";
   die;
}

$id = (int) $_GET['id'];

 $sql = "select * from product where id = {$id};";
 
 $rows = [];
$mysqli_result =$db->query($sql);
$row = $mysqli_result->fetch_array( MYSQLI_ASSOC);
if($mysqli_result == false){
    echo "SQL fail";
    exit;
}

include'template/product.html';